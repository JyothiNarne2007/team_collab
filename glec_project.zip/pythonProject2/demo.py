from flask import Flask, render_template, request, jsonify
import pymysql
import json

app = Flask(__name__)

# Database connection configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Anu@1234',
    'database': 'user_management'
}

# Helper function to connect to the database


def get_db_connection():
    return pymysql.connect(**DB_CONFIG, cursorclass=pymysql.cursors.DictCursor)


def update_year_branch_section_table():
    """
    Create or update the year_branch_section table with the active years and their associated branches and sections.
    """
    try:
        connection = get_db_connection()
        cursor = connection.cursor()

        # Create the year_branch_section table if it doesn't exist
        create_table_query = """
        CREATE TABLE IF NOT EXISTS year_branch_section (
            active_year VARCHAR(255) PRIMARY KEY,
            branch_section JSON
        )
        """
        cursor.execute(create_table_query)

        # Fetch the 4 highest passed-out years
        fetch_years_query = """
        SELECT DISTINCT Passed out year
        FROM profile
        WHERE Passed out year IS NOT NULL
        ORDER BY CAST(Passed out year AS UNSIGNED) DESC
        LIMIT 4
        """
        cursor.execute(fetch_years_query)
        active_years = cursor.fetchall()

        # Prepare the data for each active year
        for year in active_years:
            active_year = year[0]

            # Fetch branches and their sections for the current active year
            fetch_branches_query = """
            SELECT Branch, GROUP_CONCAT(DISTINCT Section ORDER BY Section) AS Sections
            FROM profile
            WHERE Passed out year = %s AND Branch IS NOT NULL AND Section IS NOT NULL
            GROUP BY Branch
            """
            cursor.execute(fetch_branches_query, (active_year,))
            branch_data = cursor.fetchall()

            # Convert branch and sections data to JSON format
            branch_section_json = {}
            for branch, sections in branch_data:
                branch_section_json[branch] = sections.split(',')

            # Insert or update the year_branch_section table
            insert_update_query = """
            INSERT INTO year_branch_section (active_year, branch_section)
            VALUES (%s, %s)
            ON DUPLICATE KEY UPDATE branch_section = VALUES(branch_section)
            """
            cursor.execute(insert_update_query, (active_year,
                           json.dumps(branch_section_json)))

        connection.commit()
        cursor.close()
        connection.close()
        print("Year branch section updated successfully!")
    except Exception as e:
        print(f"Error updating year_branch_section table: {str(e)}")


@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch all faculty for dropdown
    cursor.execute(
        "SELECT faculty_id, CONCAT(first_name, ' ', last_name) AS name FROM faculty_user")
    faculty = cursor.fetchall()

    conn.close()
    return render_template('demo.html', faculty=faculty)


@app.route('/get_years_fa', methods=['GET'])
def get_years_fa():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch distinct years
    cursor.execute("SELECT DISTINCT active_year FROM year_branch_section")
    years = [row['active_year'] for row in cursor.fetchall()]

    conn.close()
    return jsonify(years)


@app.route('/get_branches_fa', methods=['POST'])
def get_branches_fa():
    data = request.json
    year = data.get('year')

    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch branches for the selected year
    cursor.execute(
        "SELECT branch_section FROM year_branch_section WHERE active_year = %s", (year,))
    result = cursor.fetchone()
    branches = list(json.loads(
        result['branch_section']).keys()) if result else []

    conn.close()
    return jsonify(branches)


@app.route('/get_sections_fa', methods=['POST'])
def get_sections_fa():
    data = request.json
    year = data.get('year')
    branch = data.get('branch')

    if not year or not branch:
        return jsonify({'error': 'Year and branch are required'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch sections for the selected year and branch
    cursor.execute(
        "SELECT branch_section FROM year_branch_section WHERE active_year = %s", (year,))
    result = cursor.fetchone()
    print(f"Query Result for year={year}: {result}")  # Debugging

    sections = []
    if result:
        branch_section_data = json.loads(result['branch_section'])
        print(f"Branch Section Data: {branch_section_data}")  # Debugging
        sections = branch_section_data.get(branch, [])
        print(f"Sections for branch={branch}: {sections}")  # Debugging

    conn.close()
    return jsonify(sections)


@app.route('/get_subjects_by_branch_and_semester_fa', methods=['POST'])
def get_subjects_by_branch_and_semester_fa():
    data = request.json
    branch = data.get('branch')
    semester = data.get('semester')

    if not branch or not semester:
        return jsonify({'error': 'Branch and semester are required'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch department_id based on the branch
    cursor.execute(
        "SELECT department_id FROM department WHERE department_name = %s", (branch,))
    department = cursor.fetchone()

    if not department:
        conn.close()
        return jsonify({'error': 'No department found for the selected branch'}), 400

    department_id = department['department_id']

    # Fetch subjects for the department and semester
    cursor.execute(
        "SELECT subject_id, subject_name FROM subject WHERE department_id = %s AND semester = %s",
        (department_id, semester)
    )
    subjects = cursor.fetchall()

    conn.close()
    return jsonify(subjects)


@app.route('/assign_faculty_fa', methods=['POST'])
def assign_faculty_fa():
    data = request.json
    faculty_id = data.get('faculty_id')
    assignments = data.get('assignments')

    # Validate faculty_id and assignments
    if not faculty_id:
        return jsonify({'error': 'Faculty ID is required.'}), 400
    if not assignments or not isinstance(assignments, list):
        return jsonify({'error': 'Assignments must be a non-empty list.'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    for assignment in assignments:
        year_branch_section = assignment.get('year_branch_section')
        subject_id = assignment.get('subject_id')

        # Validate year_branch_section and subject_id
        if not year_branch_section or not subject_id:
            conn.close()
            return jsonify({'error': 'Each assignment must include year_branch_section and subject_id.'}), 400
        if '-' not in year_branch_section:
            conn.close()
            return jsonify({'error': f'Invalid year_branch_section format: {year_branch_section}. Expected format: year-branch-section.'}), 400

        # Split the year_branch_section into year, branch, and section
        try:
            year, branch, section = year_branch_section.split('-')
        except ValueError:
            conn.close()
            return jsonify({
                'error': f'Invalid year_branch_section format: {year_branch_section}. Expected format: year-branch-section.'
            }), 400

        # Fetch the subject code from the subject table
        cursor.execute(
            "SELECT subject_code FROM subject WHERE subject_id = %s", (subject_id,))
        subject = cursor.fetchone()

        if not subject:
            conn.close()
            return jsonify({'error': f'Subject not found for subject_id: {subject_id}.'}), 400

        subject_code = subject['subject_code']

        # Check for duplicate assignments
        query = """
            SELECT faculty_id 
            FROM faculty_assessment
            WHERE JSON_CONTAINS(assessment_data, JSON_OBJECT(%s, JSON_OBJECT(%s, JSON_ARRAY(%s))), '$')
        """
        cursor.execute(query, (subject_code, year, f"{branch} {section}"))
        existing_assignment = cursor.fetchone()

        if existing_assignment:
            conn.close()
            return jsonify({
                'error': f'Subject ({subject_code}) is already assigned to another faculty for {year_branch_section}.'
            }), 400

        # Check if the faculty already has an entry
        cursor.execute(
            "SELECT assessment_data FROM faculty_assessment WHERE faculty_id = %s", (faculty_id,))
        faculty_data = cursor.fetchone()

        if faculty_data:
            # Update the existing assessment_data
            assessment_data = json.loads(faculty_data['assessment_data'])

            if subject_code not in assessment_data:
                assessment_data[subject_code] = {}
            if year not in assessment_data[subject_code]:
                assessment_data[subject_code][year] = []
            if f"{branch} {section}" not in assessment_data[subject_code][year]:
                assessment_data[subject_code][year].append(
                    f"{branch} {section}")

            # Update the database
            cursor.execute(
                "UPDATE faculty_assessment SET assessment_data = %s WHERE faculty_id = %s",
                (json.dumps(assessment_data), faculty_id)
            )
        else:
            # Create a new entry for the faculty
            assessment_data = {
                subject_code: {
                    year: [f"{branch} {section}"]
                }
            }
            cursor.execute(
                "INSERT INTO faculty_assessment (faculty_id, assessment_data) VALUES (%s, %s)",
                (faculty_id, json.dumps(assessment_data))
            )

    conn.commit()
    conn.close()

    return jsonify({'success': 'Faculty assigned successfully!'})


if __name__ == '__main__':
    app.run(debug=True)
